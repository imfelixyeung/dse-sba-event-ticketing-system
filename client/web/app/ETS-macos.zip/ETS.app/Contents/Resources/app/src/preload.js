// document.addEventListener("DOMContentLoaded", () => {
//     const dragger = document.createElement("div");
//     dragger.classList.add("dragger");
//     const css = `

//     * {
//         -webkit-app-region: no-drag;
//     }

//     .dragger {
//         position: fixed;
//         top: 0;
//         left: 0;
//         width: 100vw;
//         height: 56px;
//         z-index: 512;
//         -webkit-user-select: none;
//         -webkit-app-region: drag;
//     }
//     `;

//     let style = document.createElement("style");
//     style.innerHTML = css;
//     document.head.append(style);
//     document.body.append(dragger);
//     console.log(dragger);
// });
